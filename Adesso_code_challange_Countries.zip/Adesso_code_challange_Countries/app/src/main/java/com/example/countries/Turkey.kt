package com.example.countries

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class Turkey : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_turkey)

        val TurkeyBackButton = findViewById<Button>(R.id.TurkeyBackButton)
        TurkeyBackButton.setOnClickListener {
            val GoBack = Intent(this,MainActivity::class.java)
            startActivity(GoBack)
        }

        val TurkeyInfoButton = findViewById<Button>(R.id.TurkeyInfoButton)
        TurkeyInfoButton.setOnClickListener {
            val goURL = Intent(Intent.ACTION_VIEW)
            goURL.data = Uri.parse("https://www.wikidata.org/wiki/Q43")
            startActivity(goURL)
        }
    }
}