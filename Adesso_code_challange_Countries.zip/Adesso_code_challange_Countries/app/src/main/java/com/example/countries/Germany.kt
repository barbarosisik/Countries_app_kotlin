package com.example.countries

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class Germany : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_germany)

        val GermanyBackButton = findViewById<Button>(R.id.GermanyBackButton)
        GermanyBackButton.setOnClickListener {
            val GoBack = Intent(this,MainActivity::class.java)
            startActivity(GoBack)
        }

        val GermanyInfoButton = findViewById<Button>(R.id.GermanyInfoButton)
        GermanyInfoButton.setOnClickListener {
            val goURL = Intent(android.content.Intent.ACTION_VIEW)
            goURL.data = Uri.parse("https://www.wikidata.org/wiki/Q183")
            startActivity(goURL)
        }
    }
}