package com.example.countries

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class Spain : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_spain)

        val SpainBackButton = findViewById<Button>(R.id.SpainBackButton)
        SpainBackButton.setOnClickListener {
            val GoBack = Intent(this,MainActivity::class.java)
            startActivity(GoBack)
        }

        val SpainInfoButton = findViewById<Button>(R.id.SpainInfoButton)
        SpainInfoButton.setOnClickListener {
            val goURL = Intent(Intent.ACTION_VIEW)
            goURL.data = Uri.parse("https://www.wikidata.org/wiki/Q29")
            startActivity(goURL)
        }
    }
}