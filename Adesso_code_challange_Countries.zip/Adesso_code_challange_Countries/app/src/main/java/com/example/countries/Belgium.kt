package com.example.countries

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class Belgium : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_belgium)

        val BelgiumBackButton = findViewById<Button>(R.id.BelgiumBackButton)
        BelgiumBackButton.setOnClickListener {
            val GoBack = Intent(this,MainActivity::class.java)
            startActivity(GoBack)
        }

        val BelgiumInfoButton = findViewById<Button>(R.id.BelgiumInfoButton)
        BelgiumInfoButton.setOnClickListener {
            val goURL = Intent(Intent.ACTION_VIEW)
            goURL.data = Uri.parse("https://www.wikidata.org/wiki/Q31")
            startActivity(goURL)
        }
    }
}