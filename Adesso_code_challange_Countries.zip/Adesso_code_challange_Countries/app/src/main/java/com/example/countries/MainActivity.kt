package com.example.countries

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val ButtonGermany = findViewById<Button>(R.id.button_germany)
        ButtonGermany.setOnClickListener {
            val IntentGermany = Intent(this,Germany::class.java)
            startActivity(IntentGermany)
        }

        val ButtonTurkey = findViewById<Button>(R.id.button_turkey)
        ButtonTurkey.setOnClickListener {
            val IntentTurkey = Intent(this,Turkey::class.java)
            startActivity(IntentTurkey)
        }

        val ButtonBelgium = findViewById<Button>(R.id.button_belgium)
        ButtonBelgium.setOnClickListener {
            val IntentBelgium = Intent(this,Belgium::class.java)
            startActivity(IntentBelgium)
        }

        val ButtonSpain = findViewById<Button>(R.id.button_spain)
        ButtonSpain.setOnClickListener {
            val IntentSpain = Intent(this,Spain::class.java)
            startActivity(IntentSpain)
        }



    }
}